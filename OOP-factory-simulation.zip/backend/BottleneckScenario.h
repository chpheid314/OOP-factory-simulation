#pragma once

#include "Scenario.h"

class BottleneckScenario
    : public Scenario
{
public:

    void apply(
        ProductionLine& line,
        int tick
    ) override;

    void reset(
        ProductionLine& line,
        int tick
    ) override;
};